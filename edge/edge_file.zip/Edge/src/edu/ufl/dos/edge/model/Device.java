package edu.ufl.dos.edge.model;

import java.io.Serializable;
/**
 * POJO class for Device.
 * 
 * 
 * @author Group-3
 *
 */
public class Device implements Serializable {

	private static final long serialVersionUID = 1L;
	private int devId;
	private String devName;
	private String state;
	private int bbbId;
	private String bbbName;
	private String mode;

	public int getBbbId() {
		return bbbId;
	}

	public void setBbbId(int bbbId) {
		this.bbbId = bbbId;
	}

	public String getBbbName() {
		return bbbName;
	}

	public void setBbbName(String bbbName) {
		this.bbbName = bbbName;
	}

	public Device() {
	}

	public Device(int devId, String devName, String state, int bbbId, String bbbName, String mode) {
		this.devId = devId;
		this.devName = devName;
		this.state = state;
		this.bbbId = bbbId;
		this.bbbName = bbbName;
		this.mode = mode;

	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getDevId() {
		return devId;
	}

	public void setDevId(int devId) {
		this.devId = devId;
	}

	public String getDevName() {
		return devName;
	}

	public void setDevName(String devName) {
		this.devName = devName;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

}
