package edu.ufl.dos.edge.dao;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import edu.ufl.dos.edge.model.Device;

/**
 * UDP server to listen to messages from BBB devices.
 *
 */
public class UDPServer {
	private static int count = 0;
	public static Map<Integer, List<String>> bbbIpLookup = new HashMap<Integer, List<String>>();
	private static final int POLLING_INTERVAL = 5000;

	/**
	 * Initialize all BBBs and retain their IPs
	 * 
	 * @throws IOException
	 * @throws ParserConfigurationException
	 * @throws SAXException
	 */
	public static void initialize() throws IOException, ParserConfigurationException, SAXException {
		DatagramSocket clientSocket = new DatagramSocket();
		try {
			for (int bbbId : DDLParser.getBBBList()) {
				InetAddress IPAddress = InetAddress.getByName("255.255.255.255");
				byte[] sendData = new byte[1024];
				byte[] receiveData = new byte[1024];
				System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(bbbId).array(), 0,
						sendData, 0, 4);
				System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(++count).array(), 0,
						sendData, 4, 4);
				System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(28).array(), 0, sendData,
						8, 4);
				System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(200).array(), 0, sendData,
						12, 4);
				ByteBuffer bytebuffer = ByteBuffer.wrap(sendData);

				DatagramPacket sendPacket = new DatagramPacket(bytebuffer.array(), bytebuffer.array().length, IPAddress,
						2222);
				// clientSocket.setSoTimeout(60000);
				clientSocket.send(sendPacket);
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				clientSocket.receive(receivePacket);
				/*
				 * try{ clientSocket.receive(receivePacket); }
				 * catch(SocketTimeoutException e){
				 * System.out.println("Socket timed out for BBB Id: "+ bbbId);
				 * e.printStackTrace(); }
				 */
				List<String> ip = new ArrayList<String>();
				ip.add(receivePacket.getAddress().toString());
				ip.add(String.valueOf(receivePacket.getPort()));

				bbbIpLookup.put(Integer.valueOf(bbbId), ip);

				Runnable thread = new Runnable() {

					@Override
					public void run() {
						poll();
					}
				};

				new Thread(thread).start();
			}
		} finally {
			clientSocket.close();
		}

	}

	/**
	 * Creates a new thread which listens to all incoming traffic towards edge.
	 * 
	 * @throws Exception
	 */
	public static void startServer() throws Exception {
		Runnable thread = new Runnable() {

			@Override
			public void run() {
				try {
					DatagramSocket serverSocket = new DatagramSocket(1111);
					// serverSocket.setSoTimeout(60000);
					try {

						while (true) {
							byte[] receiveData = new byte[1024];

							DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
							// System.out.println("in server thread!, port ="+
							// try {
							serverSocket.receive(receivePacket);
							// } catch (SocketTimeoutException e) {
							// e.printStackTrace();
							// }
							byte[] array = null;
							array = receivePacket.getData();
							int bbbId = readData(array, 0);
							// int msgId = readData(array, 4);
							int devId = readData(array, 8);
							int state = readData(array, 12);
							try {
								Device dev = DeviceDAO.deviceMap.get(bbbId + "_" + devId);

								if (dev.getDevName().equals("TEMP")) {
									double value = (((state * 1.8) / 4095.0) - 0.5) * 100;
									dev.setState(String.valueOf(value));
								} else {
									dev.setState(String.valueOf(state));
								}
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					} finally {
						serverSocket.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			}
		};

		new Thread(thread).start();
	}

	private static void poll() {

		try {
			DatagramSocket clientSocket = new DatagramSocket();
			clientSocket.setSoTimeout(10000);
			try {

				while (true) {
					for (Device dev : DeviceDAO.deviceMap.values()) {
						if (dev.getMode().equals("out")) {
							continue;
						}
						InetAddress IPAddress = InetAddress.getByName("255.255.255.255");
						byte[] sendData = new byte[1024];
						byte[] receiveData = new byte[1024];
						int msgId = ++UDPServer.count;

						System.arraycopy(
								ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(dev.getBbbId()).array(), 0,
								sendData, 0, 4);
						System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(msgId).array(), 0,
								sendData, 4, 4);
						System.arraycopy(
								ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(dev.getDevId()).array(), 0,
								sendData, 8, 4);
						System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(0).array(), 0,
								sendData, 12, 4);
						ByteBuffer bytebuffer = ByteBuffer.wrap(sendData);

						DatagramPacket sendPacket = new DatagramPacket(bytebuffer.array(), bytebuffer.array().length,
								IPAddress, 2222);
						clientSocket.send(sendPacket);

						int count = 0;
						while (count < 3) {
							count++;
							DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
							try {
								clientSocket.receive(receivePacket);
							} catch (SocketTimeoutException e) {
								break;
							}

							ByteBuffer bb1 = ByteBuffer.wrap(receivePacket.getData(), 4, 4);
							bb1.order(ByteOrder.LITTLE_ENDIAN);
							int msg = bb1.getInt();
							if (msg == msgId) {

								ByteBuffer bb2 = ByteBuffer.wrap(receivePacket.getData(), 12, 4);
								bb2.order(ByteOrder.LITTLE_ENDIAN);

								int state = bb2.getInt();
								if (dev.getDevName().equals("TEMP")) {
									double value = (((state * 1.8) / 4095.0) - 0.5) * 100;
									dev.setState(String.valueOf(value));
								} else {
									dev.setState(String.valueOf(state));
								}

								if (dev.getDevName().equals("BUTTON")) {
									int res = UDPClient.actuate(state, 2, 27);
									DeviceDAO.deviceMap.get(2 + "_" + 27).setState(String.valueOf(res));
								}
								break;
							}

						}
					}
					Thread.sleep(POLLING_INTERVAL);
				}
			} finally {
				clientSocket.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static int readData(byte[] array, int index) {
		ByteBuffer bytebuffer = ByteBuffer.wrap(array, index, 4);
		bytebuffer.order(ByteOrder.LITTLE_ENDIAN);
		return bytebuffer.getInt();
	}

	public static void main(String args[]) throws Exception {
		initialize();
		// startServer();
		/*
		 * DatagramSocket serverSocket = new DatagramSocket(3333); try {
		 * 
		 * while (true) { byte[] receiveData = new byte[1024]; byte[] sendData =
		 * new byte[1024]; DatagramPacket receivePacket = new
		 * DatagramPacket(receiveData, receiveData.length);
		 * serverSocket.receive(receivePacket); // String sentence = new
		 * String(receivePacket.getData()); byte[] array = null; array =
		 * receivePacket.getData();
		 * 
		 * 
		 * byte[] int1 = new byte[4]; byte[] int2 = new byte[4]; byte[] int3 =
		 * new byte[4]; byte[] int4 = new byte[4];
		 * 
		 * System.out.println("----------------"); for (int i = 0; i < 4; i++) {
		 * ByteBuffer bytebuffer = ByteBuffer.wrap(array, i * 4, 4);
		 * bytebuffer.order(ByteOrder.LITTLE_ENDIAN); int int1 =
		 * bytebuffer.getInt(); System.out.println(int1); }
		 */
		/*
		 * ByteBuffer bytebuffer = ByteBuffer.wrap(receivePacket.getData());
		 * bytebuffer.order(ByteOrder.LITTLE_ENDIAN); String sentence = new
		 * String(array, 0, array.length);; System.out.println(sentence);
		 */
		// reverseArray(array);
		// ByteBuffer bytebuffer = ByteBuffer.wrap(array);
		// bytebuffer.order(ByteOrder.LITTLE_ENDIAN);
		// String sentence = new String(array, 0, array.length);
		// System.out.println("RECEIVED: " + array[0]);
		// System.out.println(bytebuffer.getInt());
		// InetAddress IPAddress = receivePacket.getAddress();
		// int port = receivePacket.getPort();
		// String capitalizedSentence = sentence.toUpperCase();
		// sendData = capitalizedSentence.getBytes();
		// DatagramPacket sendPacket = new DatagramPacket(sendData,
		// sendData.length, IPAddress, port);
		// serverSocket.send(sendPacket);
		/*
		 * } } finally { serverSocket.close(); }
		 */
	}

}