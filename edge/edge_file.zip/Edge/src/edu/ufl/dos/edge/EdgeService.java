package edu.ufl.dos.edge;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import edu.ufl.dos.edge.dao.DeviceDAO;
import edu.ufl.dos.edge.model.Device;

/**
 * RESTful web-service main entry point class
 * 
 *
 */

@Path("/EdgeService")
public class EdgeService {

	DeviceDAO dao = new DeviceDAO();

	/**
	 * getDevices() gets all the devices accessible to this Edge instance.
	 * 
	 * @return List of all devices.
	 */
	@GET
	@Path("/devices")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Device> getDevices() {
		return dao.getAllDevices();
	}

	/**
	 * Gets information of a device represented by given bbbId_devId pair
	 * 
	 * @param bbbId
	 *            - Beagle bone black/planform id.
	 * @param devId
	 *            - Device Id
	 * @return Device info
	 */
	@GET
	@Path("/device/{bbbId}/{devId}")
	@Produces(MediaType.APPLICATION_JSON)
	public Device getDevice(@PathParam("bbbId") int bbbId, @PathParam("devId") int devId) {
		return dao.getDevice(bbbId, devId);
	}

	/**
	 * Actuate the device.
	 * 
	 * @param bbbId
	 *            - platform Id e.g. Beagle Bone Black
	 * @param devId
	 *            - Device id
	 * @param state
	 *            - new state
	 * @return - SUCCESS or FAILURE string.
	 */
	@GET
	@Path("/actuate/{bbbId}/{devId}/{state}")
	@Produces(MediaType.APPLICATION_JSON)
	public String actuate(@PathParam("bbbId") String bbbId, @PathParam("devId") String devId,
			@PathParam("state") String state) {

		try {
			dao.actuate(bbbId, devId, state);
		} catch (Exception e) {
			// TODO log the changes
			return "FAILURE";
		}

		return "SUCCESS";
	}

}
