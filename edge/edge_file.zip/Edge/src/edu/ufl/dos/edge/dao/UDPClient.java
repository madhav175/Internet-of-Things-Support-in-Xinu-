package edu.ufl.dos.edge.dao;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.List;

/**
 * UDP client to send data to connected platforms such as BBB.
 *
 */
public class UDPClient {

	/**
	 * Actuates a particular device. Sets states to the new state given by 'state' below.
	 * 
	 * @param state
	 * @param bbbId
	 * @param deviceId
	 * @return
	 * @throws IOException
	 */
	
	private static int msgCount = 0;
	
	public static int actuate(int state, int bbbId, int deviceId) throws IOException {

		DatagramSocket clientSocket = new DatagramSocket();
		int returnValue = -1;
		try {
			List<String> ipLookup = UDPServer.bbbIpLookup.get(bbbId);
			String ip = ipLookup.get(0);
			int port = Integer.parseInt(ipLookup.get(1));
			
			//InetAddress IPAddress = InetAddress.getByName((ip.split("/")[1]));
			InetAddress IPAddress = InetAddress.getByName("255.255.255.255");
			byte[] sendData = new byte[1024];
			byte[] receiveData = new byte[1024];
			int msgId = ++msgCount;

			System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(bbbId).array(), 0, sendData,
					0, 4);
			System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(msgId).array(), 0, sendData,
					4, 4);
			System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(deviceId).array(), 0,
					sendData, 8, 4);
			System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(state).array(), 0, sendData,
					12, 4);
			ByteBuffer bytebuffer = ByteBuffer.wrap(sendData);

			DatagramPacket sendPacket = new DatagramPacket(bytebuffer.array(), bytebuffer.array().length, IPAddress,
					port);
			clientSocket.send(sendPacket);

			int count = 0;
			while (count < 3) {
				count++;
				DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
				clientSocket.receive(receivePacket);

				ByteBuffer bb1 = ByteBuffer.wrap(receivePacket.getData(), 4, 4);
				bb1.order(ByteOrder.LITTLE_ENDIAN);
				int msg = bb1.getInt();
				if (msg == msgId) {
					ByteBuffer bb2 = ByteBuffer.wrap(receivePacket.getData(), 12, 4);
					bb2.order(ByteOrder.LITTLE_ENDIAN);
					returnValue = bb2.getInt();
					break;
				}

			}

		} finally

		{
			clientSocket.close();
		}

		return returnValue;

	}

	public static void main(String args[]) throws Exception {
		// BufferedReader inFromUser = new BufferedReader(new
		// InputStreamReader(System.in));
		DatagramSocket clientSocket = new DatagramSocket();
		InetAddress IPAddress = InetAddress.getByName("255.255.255.255");
		byte[] sendData = new byte[1024];
		byte[] receiveData = new byte[1024];
		/*
		 * int b1 = 1; int b2 = 2; int b3 = 0; int b4 = 200;
		 */

		// String data = "I sent this!";

		System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(1).array(), 0, sendData, 0, 4);
		System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(2).array(), 0, sendData, 4, 4);
		System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(27).array(), 0, sendData, 8, 4);
		System.arraycopy(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(1).array(), 0, sendData, 12, 4);
		ByteBuffer bytebuffer = ByteBuffer.wrap(sendData);
		// bytebuffer.order(ByteOrder.LITTLE_ENDIAN);

		/*
		 * sendData[0]=1; sendData[1]=0; sendData[2]=0; sendData[3]=0;
		 * sendData[4]=1; sendData[5]=0; sendData[6]=0; sendData[7]=0;
		 * sendData[8]=2; sendData[9]=0; sendData[10]=0; sendData[11]=0;
		 * sendData[12]=(byte)200; sendData[13]=(byte)200;
		 * sendData[14]=(byte)200; sendData[15]=(byte)200;
		 */

		// sendData =receiveData
		// sendData =
		// DatagramPacket sendPacket = new DatagramPacket(data.getBytes(),
		// data.getBytes().length, IPAddress, 3333);
		// DatagramPacket sendPacket = new DatagramPacket(sendData,
		// sendData.length, IPAddress, 2222);
		DatagramPacket sendPacket = new DatagramPacket(bytebuffer.array(), bytebuffer.array().length, IPAddress, 2222);
		clientSocket.send(sendPacket);
		DatagramPacket receivePacket = new DatagramPacket(receiveData, receiveData.length);
		clientSocket.receive(receivePacket);

		System.out.println("----------------");
		for (int i = 0; i < 4; i++) {
			ByteBuffer bytebuffe1r = ByteBuffer.wrap(receivePacket.getData(), i * 4, 4);
			bytebuffe1r.order(ByteOrder.LITTLE_ENDIAN);
			int int1 = bytebuffe1r.getInt();
			System.out.println(int1);
		}
		// String modifiedSentence = new String(receivePacket.getData());
		// String modifiedSentence = new String(receivePacket.getData());
		// System.out.println("FROM SERVER:" + modifiedSentence);
		clientSocket.close();
	}
}
