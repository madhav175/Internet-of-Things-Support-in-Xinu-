package edu.ufl.dos.edge.dao;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import edu.ufl.dos.edge.model.Device;

public class DDLParser {
	private static List<Device> devList = null;
	private static List<Integer> bbbList = new ArrayList<Integer>();

	public static void main(String argd[]) throws ParserConfigurationException, SAXException, IOException {
		getDeviceList();
	}

	public static List<Device> parseDeviceListXml() throws ParserConfigurationException, SAXException, IOException {
		List<Device> devList = new ArrayList<Device>();
		File xml = new File("device.xml");
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
		Document document = dBuilder.parse(xml);
		document.getDocumentElement().normalize();
		NodeList bbbNodes = document.getElementsByTagName("devices");

		for (int i = 0; i < bbbNodes.getLength(); i++) {
			Node nNode = bbbNodes.item(i);
			if (nNode.getNodeType() == Node.ELEMENT_NODE) {
				Element ele = (Element) nNode;
				String bbbName = ele.getAttribute("name");
				int bbbId = Integer.parseInt(ele.getAttribute("id"));
				bbbList.add(bbbId);
				NodeList deviceList = ele.getElementsByTagName("device");
				for (int j = 0; j < deviceList.getLength(); j++) {
					Node node = deviceList.item(j);
					if (node.getNodeType() == Node.ELEMENT_NODE) {
						Element nodeEle = (Element) node;
						Device dev = new Device();
						dev.setDevId(Integer.parseInt(nodeEle.getAttribute("index")));
						dev.setDevName(nodeEle.getAttribute("name"));
						Element modeElement = (Element) nodeEle.getElementsByTagName("mode").item(0);
						dev.setMode(modeElement.getAttribute("name"));
						dev.setBbbName(bbbName);
						dev.setBbbId(bbbId);
						dev.setState(String.valueOf(0));
						devList.add(dev);
					}
				}
			}
		}

		return devList;
	}

	public static List<Device> getDeviceList() throws ParserConfigurationException, SAXException, IOException {
		if (devList == null) {
			devList = parseDeviceListXml();
			return devList;
		}
		return devList;
	}

	public static List<Integer> getBBBList() throws ParserConfigurationException, SAXException, IOException {
		if (devList == null) {
			devList = parseDeviceListXml();
			return bbbList;
		}
		return bbbList;
	}

}